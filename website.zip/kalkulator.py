def tambah(a,b):
    return a + b
    
def bagi(a,b):
    return a / b

def kurang(a,b):
    return a- b 

def kali(a,b):
    return a * b 



angka1 = int(input("Masukan Angka Pertama: "))
angka2 = int(input("Masukan Angka Kedua: "))
operasi = input("masukan operasi : bagi , kali , tambah , kurang: ")




if operasi == "tambah":
    hasil = tambah(angka1,angka2)
    print("hasil dari",angka1, "tambah", angka2,"adalah", hasil)


if operasi == "kurang":
    hasil = kurang(angka1,angka2)
    print("hasil dari",angka1, "tambah", angka2,"adalah", hasil)

if operasi == "bagi":
    hasil = bagi(angka1,angka2)
    print("hasil dari",angka1, "tambah", angka2,"adalah", hasil)

if operasi == "kali":
    hasil = kali(angka1,angka2)
    print("hasil dari",angka1, "tambah", angka2,"adalah", hasil)
