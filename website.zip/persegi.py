panjang = int(input("Berapa panjang nya ?: "))
lebar = int(input("Berapa lebar nya ?: "))

luas = panjang * lebar
print("Luas Persegi Panjang adalah", luas)

keliling = 2 * panjang + lebar 
print("Keliling persegi panjang adalah", keliling)