tahun = int(input("Masukan tahun: "))
if tahun / 4 == 0:
    print (tahun,"adalah Tahun kabisat")
else :
    print (tahun,"bukan tahun kabisat")